//
//  ViewController.swift
//  webapp
//
//  Created by Bronson Dupaix on 2/23/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import UIKit



class ViewController: UIViewController {
    
    var friendsArray = [Friend]()
    
    var apiClient = GitHubAPI()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("hello")
        
        
        self.apiClient.fetchUsers()
        
    
    } // end view did load

} // end view controller