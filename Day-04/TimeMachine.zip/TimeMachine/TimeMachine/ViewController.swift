//
//  ViewController.swift
//  TimeMachine
//
//  Created by Bronson Dupaix on 2/4/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var destinationLabel: UILabel!
    
    
    @IBOutlet weak var presentLabel: UILabel!
    
    @IBOutlet weak var speedLabel: UILabel!
    
    @IBAction func setDestinationButton(sender: AnyObject) {
        
    }
    
    var destination : String = ""
        
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        print("segue")
    }
    
    @IBAction func exitSegue(segue: UIStoryboardSegue) {
        
        
        print("exitedSegue") 
    }

    
    @IBAction func travelBackButton(sender: AnyObject) {
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
   
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}



