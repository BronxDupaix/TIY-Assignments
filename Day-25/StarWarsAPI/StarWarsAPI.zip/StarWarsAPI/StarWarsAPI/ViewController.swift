//
//  ViewController.swift
//  StarWarsAPI
//
//  Created by Bronson Dupaix on 3/5/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var api = StarWarsAPI()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        api.fetchCharacter("\(1)") 
        

    } 



}

