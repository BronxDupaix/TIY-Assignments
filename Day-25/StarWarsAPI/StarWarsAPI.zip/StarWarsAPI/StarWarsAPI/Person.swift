//
//  Person.swift
//  StarWarsAPI
//
//  Created by Bronson Dupaix on 3/5/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import Foundation
import CoreData


class Person: NSManagedObject {

  
}
