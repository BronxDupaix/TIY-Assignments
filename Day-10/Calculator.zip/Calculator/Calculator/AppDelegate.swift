//
//  ViewController.swift
//  Calculator
//
//  Created by Phil Wright on 2/10/16.
//  Copyright © 2016 Phil Wright. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        return true
    }

}

