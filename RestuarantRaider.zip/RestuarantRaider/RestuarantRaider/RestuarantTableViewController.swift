//
//  RestuarantTableViewController.swift
//  RestuarantRaider
//
//  Created by Bronson Dupaix on 2/18/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import UIKit

typealias JSONDictionary = [String: AnyObject]
typealias JSONArray = [JSONDictionary]

class RestuarantTableViewController: UITableViewController {
    
    var restuarantArray = [Restuarant]()
    
    var currentRestuarant: Restuarant?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let (jsonString, data) = self.loadJSONFile("restuarants", fileType: "json")
        
        
        
        if let data = data{
            do {
                let object = try NSJSONSerialization.JSONObjectWithData(data, options: .AllowFragments)
                
                if let dict = object as? JSONDictionary {
                    
                   parseJson(dict)
                    
                    
                }
            } catch {
                
                print("Data Error - Unable to parse the original jsonString")
            }
        }
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {

        return restuarantArray.count
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return 1
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        
        
        self.currentRestuarant = restuarantArray[indexPath.row]
        
        let cell = UITableViewCell()
        
        let name = self .currentRestuarant!.name
        
        print(name)
        
        cell.textLabel?.text = "\(name)"

        return cell
    }
    
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        self.currentRestuarant = restuarantArray[indexPath.row]
        
        performSegueWithIdentifier("restuarantProfileSegue", sender: self)
        
        print("segue performed") 
        
    }

    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "restuarantProfileSegue" {
            let viewcontroller = segue.destinationViewController as? RestuarantProfileViewController
            
            viewcontroller?.restuarant = self.currentRestuarant
            
            
        }
        
    }

    
    func parseJson(dict: JSONDictionary) {
        
        if let results = dict["restuarants"] as? JSONArray{
            
            for result in results{
                
                let r = Restuarant()
                
                
                if let name = result["name"] as? String {
                    
                r.name = name
                    }
                
                if let style = result["style"] as? String{
                    
                    
                    r.style = style
                }
                
                
                if let address = result["address"] as? String {
                    
                    r.address = address
                }
                
                if let ourRating = result["ourRating"] as? Int {
                    
                    r.ourRating = ourRating
                }
                
                let m = Menu()
                
                if let menuName = result["entrees"] as? String {
                    
                    m.menuName = menuName
                }
                
                let d = Dish()
                
                if let dishName = result["dishName"] as? String {
                    
                    d.dishName = dishName
                }
                
                if let description = result["description"] as? String {
                    
                    d.description = description
                }
                
                if let photo = result["photo"] as? String {
                    
                    d.photo = photo 
                }
              
                self.restuarantArray.append(r)
            }
            

            
        }
        
        
        
    }
    
    func loadJSONFile(filename: String, fileType: String) -> (String, NSData?) {
        
        var returnString = ""
        var data: NSData? = nil
        
        guard let filePath = NSBundle.mainBundle().URLForResource(filename, withExtension: fileType) else { return (returnString, data) }
        
        if let jsondata = NSData(contentsOfURL: filePath) {
            if let jsonString = NSString(data: jsondata, encoding: NSUTF8StringEncoding) {
                returnString = jsonString as String
                data = jsondata
            }
        }
        return (returnString, data)
    }



}
