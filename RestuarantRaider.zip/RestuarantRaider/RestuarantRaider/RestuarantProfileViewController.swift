//
//  RestuarantProfileViewController.swift
//  RestuarantRaider
//
//  Created by Bronson Dupaix on 2/18/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import UIKit

class RestuarantProfileViewController: UIViewController {
    
    var restuarant: Restuarant?

    @IBOutlet weak var restuarantNameLabel: UILabel!
    
    
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        
        restuarantNameLabel.text = "\(restuarant!.name)"
        
        
        
    }



}
