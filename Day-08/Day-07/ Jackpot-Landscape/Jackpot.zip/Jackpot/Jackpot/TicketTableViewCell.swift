//
//  TicketTableViewCell.swift
//  Jackpot
//
//  Created by Bronson Dupaix on 2/9/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import UIKit

class TicketTableViewCell: UITableViewCell {

    @IBOutlet weak var labelOne: UILabel!
    
    
    @IBOutlet weak var labelTwo: UILabel!
    
    @IBOutlet weak var labelThree: UILabel!
    
    @IBOutlet weak var labelFour: UILabel!
    
    
    @IBOutlet weak var labelFive: UILabel!
    
    
    @IBOutlet weak var labelSix: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    

}
