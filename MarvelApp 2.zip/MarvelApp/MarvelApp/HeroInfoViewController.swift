//
//  HeroInfoViewController.swift
//  MarvelApp
//
//  Created by Bronson Dupaix on 2/8/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import UIKit

class HeroInfoViewController: UIViewController {

    

    
}
