//
//  Dishes.swift
//  RestuarantRaider
//
//  Created by Bronson Dupaix on 2/18/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import Foundation


class Dish{
    
    
    var  dishName: String = ""
    
    var  description: String = ""
    
    var  photo: String = ""
    
    var price: String = "" 
    
    
    init(dict: JSONDictionary) {
        
    }
    
    
}