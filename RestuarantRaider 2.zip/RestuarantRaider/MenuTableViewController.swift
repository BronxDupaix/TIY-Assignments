//
//  MenuTableViewController.swift
//  RestuarantRaider
//
//  Created by Bronson Dupaix on 2/18/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import UIKit

class MenuTableViewController: UITableViewController {
    
    var restuarant: Restuarant?
    
    var menu: Menu?
    
    var dishesArray = [Dish]()
    
    var dishes: Dish?

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("\(restuarant!.name)")
        
        
        
        
        print("viewMenu") 

    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        self.menu = restuarant!.menus.first
        
        print("\(menu!.menuName)")
        
        self.dishes = menu!.dishes.first
        
        print("\(dishes!.dishName)")
        
        for dish in (menu!.dishes) {
            
            dishesArray.append(dish)
            
            
           
        }
        
    }



    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        return dishesArray.count
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
//        self.dishesArray[indexPath.row]
        
        let cell = tableView.dequeueReusableCellWithIdentifier("menuCellOne", forIndexPath: indexPath)
        
        // cell.textLabel?.text = menu?.dishName[indexPath.row]
        
        

        return cell
    }




}
