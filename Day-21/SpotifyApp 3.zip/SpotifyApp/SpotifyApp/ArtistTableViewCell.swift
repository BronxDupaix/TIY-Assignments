//
//  ArtistTableViewCell.swift
//  SpotifyApp
//
//  Created by Bronson Dupaix on 3/1/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import UIKit

class ArtistTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var nameLabel: UILabel!
    


}
