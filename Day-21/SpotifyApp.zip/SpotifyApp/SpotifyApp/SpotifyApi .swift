//
//  SpotifyApi .swift
//  SpotifyApp
//
//  Created by Bronson Dupaix on 2/29/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import Foundation


class SpotifyApi {
    
    func fetchArtist(artist: String) {
        
        
        let urlString = "https://api.spotify.com/v1/search?q=\(artist)&type=artist"
        
        
        if let url = NSURL(string: urlString)
        {
            
            let session = NSURLSession.sharedSession()
            
            let task = session.dataTaskWithURL(url, completionHandler: {
                
                (data, response, error) -> () in
                
                if error != nil {
                    debugPrint("an error occured \(error)")
                }else {
                    
                    
                    // print(data)
                    
                    if let data = data {
                        
                        do {
                            // Step One Dictionary
                            if let dictionary = try NSJSONSerialization.JSONObjectWithData(data, options: .AllowFragments) as? JSONDictionary {
                                
                                // print(dictionary)
                                
                                if let artistsDict = dictionary["artists"] as?  JSONDictionary {
                                    
                                   var arrayOfArtists = [Artist]()
                                    
                                    if let itemsArray = artistsDict["items"] as? JSONArray {
                                        
                                        
                                        if let itemDict = itemsArray.first {
                                            let a = Artist(dict: itemDict)
                                            
                                            print(a.name)
                                            
                                           // print(a.artistID)
                                            
                                            self.fetchAlbum(a.artistID)
                                        }
                                        
                                        
                                        
                                        
                                        
                                    }else {
                                        print( " i couldnt loop through artists")
                                        
                                        
                                    }
                                } else {
                                    print(" coudnt get artists from dictionary")
                                }
                                
                                
                                
                            } else {
                                debugPrint("cant parse dictionary")
                            }
                            
                        } catch {
                            
                            debugPrint("cant parse JSON")
                            
                        }
                    }
                }
                
            })
            
            task.resume()
            
        } else {
            debugPrint("cant print data")
        }
        
    }
    
    func fetchAlbum(artistID: String) {
        
        
        let urlString = "https://api.spotify.com/v1/artists/\(artistID)/albums"
        
        if let url = NSURL(string: urlString)
        {
            
            let session = NSURLSession.sharedSession()
            
            let task = session.dataTaskWithURL(url, completionHandler: {
                
                (data, response, error) -> () in
                
                if error != nil {
                    debugPrint("an error occured \(error)")
                }else {
                    
                    
                     // print(data)
                    
                    if let data = data {
                        
                        do {
                            
                            if let albumDict = try NSJSONSerialization.JSONObjectWithData(data, options: .AllowFragments) as? JSONDictionary {
                                
                                 print(albumDict)
                                
                                
                            } else {
                                debugPrint("cant parse dictionary")
                            }
                            
                        } catch {
                            
                            debugPrint("cant parse JSON")
                            
                        }
                    }
                }
                
            })
            
            task.resume()
            
        } else {
            debugPrint("cant print data")
        }
        
    }
    
    
    
    
    func fetchTracks(albumID: String) {
        
        
        let urlString = "https://api.spotify.com/v1/albums/\(albumID)/tracks"
        
        if let url = NSURL(string: urlString)
        {
            
            let session = NSURLSession.sharedSession()
            
            let task = session.dataTaskWithURL(url, completionHandler: {
                
                (data, response, error) -> () in
                
                if error != nil {
                    debugPrint("an error occured \(error)")
                }else {
                    
                    
                    // print(data)
                    
                    if let data = data {
                        
                        do {
                            
                            if let trackDict = try NSJSONSerialization.JSONObjectWithData(data, options: .AllowFragments) as? JSONDictionary {
                                
                                // print(dictionary)
                                
                                
                            } else {
                                debugPrint("cant parse dictionary")
                            }
                            
                        } catch {
                            
                            debugPrint("cant parse JSON")
                            
                        }
                    }
                }
                
            })
            
            task.resume()
            
        } else {
            debugPrint("cant print data")
        }
        
    }
    
    
}