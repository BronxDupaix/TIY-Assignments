//
//  LocationsViewController.swift
//  RestuarantRaider
//
//  Created by Bronson Dupaix on 2/19/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import UIKit

class LocationsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }


}
