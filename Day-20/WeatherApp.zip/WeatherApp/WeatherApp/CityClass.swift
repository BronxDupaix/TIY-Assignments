//
//  CityClass.swift
//  WeatherApp
//
//  Created by Bronson Dupaix on 2/26/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import Foundation

class City {
    
    var cityName: String = ""
    
    var longitude: Double = -111.895387 
    
    var latitude: Double = 40.635532 
    
}