//
//  APILocation.swift
//  WeatherApp
//
//  Created by Bronson Dupaix on 2/27/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import Foundation


class ApiLocation {
    
    var delegate: LocationRetrieveProtocol?
    
    
    
}