//
//  CityClass.swift
//  WeatherApp
//
//  Created by Bronson Dupaix on 2/26/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import Foundation

class City {
    
    // var delegate: LocationRetrieveProtocol?

    var cityName: String = ""
    
    var longitude: Double = 0.00
    
    var latitude: Double = 0.00 
    
}